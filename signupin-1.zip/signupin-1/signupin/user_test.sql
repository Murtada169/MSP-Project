-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 05, 2022 at 06:13 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `user_test`
--

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `fname` varchar(255) NOT NULL,
  `flname` varchar(255) NOT NULL,
  `fdob` date NOT NULL,
  `funame` varchar(255) NOT NULL,
  `femail` varchar(255) NOT NULL,
  `pass` varchar(255) NOT NULL,
  `fphone` int(20) NOT NULL,
  `role` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `validation_key` text NOT NULL,
  `otp` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `fname`, `flname`, `fdob`, `funame`, `femail`, `pass`, `fphone`, `role`, `created_at`, `updated_at`, `validation_key`, `otp`) VALUES
(1, 'kamran', 'akmal', '2022-10-21', 'asa', 'asa@ka.com', '3b712de48137572f3849aabd5666a4e3', 353462456, 0, '2022-10-22 19:06:50', '2022-10-22 19:06:50', '', 0),
(2, 'asdf', 'sdfasfa', '2022-10-20', 'asa', 'asdfasdf@lksdaf.com', '3b712de48137572f3849aabd5666a4e3', 2341534, 0, '2022-10-22 19:07:37', '2022-10-22 19:07:37', '', 0),
(5, 'test', 'test', '2022-11-05', 'test', 'saraw34507@hoxds.com', '16d7a4fca7442dda3ad93c9a726597e4', 2147483647, 0, '2022-11-05 16:55:12', '2022-11-05 16:55:12', 'NTYzOGFlMTYxNjRkZmI3NjI3NTM5ZmYz', 792576),
(6, 'demo', 'demo', '2022-11-05', 'demo', 'xabojel539@keshitv.com', '16d7a4fca7442dda3ad93c9a726597e4', 2147483647, 0, '2022-11-05 17:09:35', '2022-11-05 17:09:35', 'OWE5YjE0MmI1MDRmZmZjNjc4MmI4OGQx', 286943);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
