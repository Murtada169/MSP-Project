<!--footer-->
<footer>
		<div class="foot-content">

			<div class="navbox">
				<h2> Navigator</h2>
				<ul>
					<li><a href="TBD">TBD</a></li>
					<li><a href="TBD">TBD</a></li>
					<li><a href="TBD">TBD</a></li>
					<li><a href="TBD">TBD</a></li>
					<li><a href="TBD">TBD</a></li>
					<li><a href="TBD"> Home</a></li>
				</ul>
			</div>
			<div class="leftside">
				<h2>About Us</h2>
				<p>Cacti-Succulent Kuching is a local homegrown business specialized in selling various
					type and size of succulent plants. Apart from selling succulent plants, they also sell different
					type
					of gardening tools, soils and fertilizers at an affordable cost. Cacti-Succulent Kuching is setup in
					2020 in which business is running both at home as well as weekend market.</p>
				<h3>"We Bring Good Things to Life"</h3>
				<h3>Provide the Best Experience within a Single Touch.</h3>
			</div>
			<div class="rightside">
				<h2>Visit Us</h2>
				<h3>Social Media</h3>
				<ol>
					<li><a href="https://youtube.com" class="button" target="_blank">Youtube</a></li>
					<li><a href="https://facebook.com" class="button" target="_blank">Facebook</a></li>
					<li><a href="https://instagram.com" class="button" target="_blank">Instagram</a></li>
					<li><a href="https://whatsapp.com" class="button" target="_blank">Whatsapp</a></li>
				</ol>
			</div>
		</div>

	</footer>

    <script src="js/script.js"></script>

</body>

</html>