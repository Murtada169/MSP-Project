<?php
require_once('config.php');
require_once("functions.php");
?>
<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8" />
	<meta name="description" content="sign up " />
	<meta name="keywords" content=", sign up" />
	<meta name="author" content="Munaamullah Khan" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0" />
	<meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $currentPage; ?></title>

    <!-- BOOTSTRAP CSS -->
    <!-- <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous"> -->
	<TITLE>Login Page</TITLE>
	<!-- <link href="assets/css/phppot-style.css" type="text/css" rel="stylesheet" />
	<link href="assets/css/user-registration.css" type="text/css" rel="stylesheet" /> -->
	<title>Login</title>

	<link rel="stylesheet" href="css/style.css">
</head>

<body>

	<?php
    require_once("php-vendor/autoload.php");

    use PHPMailer\PHPMailer\PHPMailer;
    use PHPMailer\PHPMailer\SMTP;
    use PHPMailer\PHPMailer\Exception;

    $mail = new PHPMailer();
    $mail->isSMTP();
    $mail->SMTPAuth = true;
    $mail->Host = "smtp.gmail.com";
    $mail->Port = "465";
    $mail->SMTPSecure = "ssl";

    $mail->Username = "mmunaam02@gmail.com";
    $mail->Password = "shikwgwztsyixxxg";

    $mail->setFrom("mmunaam02@gmail.com");
    $mail->addReplyTo("no-reply@Email");