<?php $currentPage = "New Password"; ?>
<?php require_once('header.php');

if (isset($_GET['token'])) {
	$otp = $_GET['token'];

	if (isset($_POST['submit'])) {
		$pass = $_POST['pass'];
		$c_pass = $_POST['cpass'];

		if ($pass == $c_pass) {

			$password = md5($pass);

			$query = "UPDATE `users` SET `pass` = '$password'  WHERE `otp` = $otp";

			$query_run = mysqli_query($conn, $query);

			if (!$query_run) {
				echo "Connection error";
			} else {
				$success = "Password has been changed successfully!";
			}
		} else {
			$errPass = "Password doesn't match!";
		}
	}
}

?>

<header>
	<a href="TBD">
		<h1 class="Logo"> Cacti-Succulent </h1>
	</a>
	<nav>
		<div class="dropdown-content">
			<ul class="link" id="mainUl">

				<li><a href="login.php">Log in</a></li>
				<li><a href="TBD">TBD</a></li>
				<li><a href="TBD">TBD</a></li>
				<li><a href="TBD">TBD</a></li>
			</ul>
		</div>
	</nav>
	<a class="about" href="TBD">TBD</a>
</header>
<div class="prime">
	<form id="form" action="" method="POST">

		<fieldset>
			<legend>
				<h1 class="form">Reset your password</h1>
			</legend>
			<?php echo isset($err) ? "<span class='form-control alert alert-danger'>{$err}</span>" : ""  ?>
			<?php echo isset($success) ? "<span class='form-control alert alert-success'>{$success}</span>" : ""  ?>
			<div class="formdetails">
				<label for="funame"> Enter Your New Password :* </label><input id="funame" name="pass" type="password" placeholder="New Password" /><br /><br /><br />
				<label for="funame"> Confirm Your Password :* </label><input id="funame" name="cpass" type="password" placeholder="Repeat Password" /><br /><br /><br />
			</div>
		</fieldset>


		<fieldset id="buttons">
			<button class="fbutton" type="submit" name="submit">Change Password</button>
			<a class="fbutton" href="login.php">Go Back</a>
		</fieldset>
	</form>




</div>
<?php include 'footer.php' ?>