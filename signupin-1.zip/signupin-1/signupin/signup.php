<?php
	$currentPage = "Signup";

	session_start();
	require("config.php");
	require("model.php");
	require("header.php");
	if(!empty($_POST['funame'])){
		$model = new Model($conn);
		$inserted = $model->insertData($_POST);
		if($inserted){
			if(!empty($_SESSION['success'])){
			   header('Location: login.php', true);
			   die();
			}
		}else{
			die($_SESSION['error']);
		}
		$conn->close();
	}
?>
	<header>
		<a href="TBD">
			<h1 class="Logo"> Cacti-Succulent </h1>
		</a>
		<nav>
			<div class="dropdown-content">
				<ul class="link" id="mainUl">

					<li><a href="login.php">Log in</a></li>
					<li><a href="TBD">TBD</a></li>
					<li><a href="TBD">TBD</a></li>
					<li><a href="TBD">TBD</a></li>
				</ul>
			</div>
		</nav>
		<a class="about" href="TBD">TBD</a>
	</header>
	<div class="prime">
		<form id="form" action="signup.php" method="POST">
		
			<fieldset>
				<legend>
					<h1 class="form">Personal Details</h1>
				</legend>
				<div class="formdetails">
					<label for="fname"> First Name* : </label><input type="text" id="fname" name="fname"
					pattern="[a-zA-Z]+" placeholder="Chong" maxlength="20" required="required"/><br>
					<label for="flname"> Last Name* : </label><input id="flname" name="flname" type="text"
					pattern="[a-zA-Z]+" maxlength="20" placeholder="Qing" required="required"/><br>
					<label for="fdob"> Date Of Birth* : </label><input id="fdob" name="fdob" type="date"
						required="required"/><br>
					<label for="funame"> User Name* : </label><input id="funame" name="funame" type="text"
					 maxlength="10" pattern="/^[a-z\d\-_\s]+$/i" placeholder="User Name" required="required"/><br>
					<label for="femail"> Email Address* : </label>
					<input onchange="validateEmail()" id="femail" name="femail" type="email"
						placeholder="someone@example.com" required="required"/><br>
						<label for="fphone"> Phone Number* : </label>
						<input onkeypress="return validateNumber(event)" id="fphone" name="fphone" type="tel"
							pattern="[0-9]{0-10}" maxlength="10" placeholder="##########"
							required="required" /><br>
							<label for = 
							<input name="password" id="password" type="text" size="15" maxlength="100" onkeyup="return passwordChanged();" />
<span id="strength"></span> 
							<label for="pass"> Password* :</label><br>
					<input id="pass" type="password" name="pass" placeholder="Enter Password"
						required="required"><br>
						<label for="confirm_pass">Confirm Password* :</label>
					<input id="confirm_pass" type="password" name="confirm_pass" placeholder="Confirm Password"
						required="required" onkeyup="validate_password()" /><br>
						<span id="wrong_pass_alert"></span><br>
					
				</div>
			</fieldset>


			<fieldset id="buttons">
				<!-- <button class="fbutton" type="submit">Sign UP</button> -->
				<button class="fbutton" type="button" onclick="submitData(event);">Sign UP</button>
				<button class="fbutton" type="reset" value="reset">Reset</button>
			</fieldset>
		</form>




	</div>
	
	<?php include 'footer.php' ?>