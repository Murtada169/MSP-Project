<?php $currentPage = "Forget Password"; ?>
<?php
session_start();
ob_start();
require_once('header.php');

if (isset($_POST['submit'])) {

	$email = $_POST['email'];

	$query = "SELECT * FROM users WHERE femail = '$email'";

	$query_run = mysqli_query($conn, $query);

	$resor = mysqli_fetch_assoc($query_run);

	$token = $resor['validation_key'];

	$count = mysqli_num_rows($query_run);

	if ($count > 0) {
		//generate otp
		$otp = rand(100000, 999999);

		$_SESSION['otp'] = $otp;

		//send otp
		$mail->addAddress($email);

		$result = mysqli_fetch_assoc($query_run);

		$token = $result['validation_key'];
		$expire_date = date("Y-m-d H-i-s", time() + 120);
		$expire_date = base64_encode(urlencode($expire_date));

		$mail->isHTML();
		$mail->Subject = "Reset your password";
		$mail->Body = "<h2>Use the code to reset password</h2>
		<h2>The OTP is $otp</h2>";

		if ($mail->send()) {

			$result = mysqli_query($conn, "UPDATE users SET otp = '$otp' WHERE femail = '$email'");

			header("location: otp.php?email='$email'");
			$current_id = mysqli_insert_id($conn);

			if (!empty($current_id)) {
				header("location: otp.php?email='$email'&eid='$token'");
			} else {
				echo "otp not found";
			}
		} else {
			echo "not";
		}
	} else {
		$err = "Sorry Email not found!";
	}
}
?>



<header>
		<a href="TBD">
			<h1 class="Logo"> Cacti-Succulent </h1>
		</a>
		<nav>
			<div class="dropdown-content">
				<ul class="link" id="mainUl">

					<li><a href="login.php">Log in</a></li>
					<li><a href="TBD">TBD</a></li>
					<li><a href="TBD">TBD</a></li>
					<li><a href="TBD">TBD</a></li>
				</ul>
			</div>
		</nav>
		<a class="about" href="TBD">TBD</a>
	</header>
	<div class="prime">
		<form  id="form" action="" method="POST">
		
			<fieldset>
				<legend>
					<h1 class="form">Forgot your password?</h1>
				</legend>
				<?php echo isset($err) ? "<span class='form-control alert alert-danger'>{$err}</span>" : ""  ?>
				<?php echo isset($success) ? "<span class='form-control alert alert-success'>{$success}</span>" : ""  ?>
				<div class="formdetails">
					<label for="funame"> Email :* </label><input id="funame" name="email" type="email"
						placeholder="Email"/><br /><br /><br />
				</div>
			</fieldset>


			<fieldset id="buttons">
				<button class="fbutton" type="submit" name="submit">Get OTP</button>
				<a class="fbutton" href="login.php">Go Back</a>
			</fieldset>
		</form>




	</div>
<?php include 'footer.php' ?>