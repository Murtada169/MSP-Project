let allImage = document.querySelectorAll(".holdImages");
let mainImage = document.querySelector(".mainImagefull");
allImage.forEach((image) => {
  image.addEventListener("click", (e) => {
    mainImage.src = e.target.src;
  });
});

//increment and decrement
let plusbtn = document.querySelector(".plus");
let minusbtn = document.querySelector(".minus");
let showNumberbtn = document.querySelector(".showNumber");
let showNumberbtntop = document.querySelector(".numbershow");

plusbtn.addEventListener("click", () => {
  let value = showNumberbtn.innerText;
  let value1 = showNumberbtntop.innerText;
  showNumberbtn.innerText = parseInt(value) + 1;
  showNumberbtntop.innerText = parseInt(value1) + 1;
});
minusbtn.addEventListener("click", () => {
  let value = showNumberbtn.innerText;
  let value1 = showNumberbtntop.innerText;
  showNumberbtn.innerText = parseInt(value) - 1;
  showNumberbtntop.innerText = parseInt(value1) - 1;
});
