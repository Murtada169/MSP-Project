<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css"
    />
    <link rel="stylesheet" href="eachpage.css" />
    <title>product page</title>
  </head>
  <body>
    <!-- navigition menu -->
    <div class="navvar forall">
      <div class="logo">
        <img src="../image/logo.jpg" alt="">
      </div>
      <div class="allnavsc">
        
        <div class="eachnav notibgc">
          <h4 class="contenttext">
           Notification
          </h4>
        </div>
        <div class="eachnav hmbgc">
          <i class="fa fa-home" aria-hidden="true"></i>
          <h4 class="contenttext">
           Admin Home
          </h4>
        </div>
        <div class="eachnav">
          <i class="fa fa-calendar" aria-hidden="true"></i>
          <h4 class="contenttext">
            Manage Booking
          </h4>
        </div>
        <div class="eachnav bigvlg">
          <span class="big">i</span>
          <h4 class="contenttext">
            Manage Advertisment
          </h4>
        </div>

          <div class="eachnav">
          <h4 class="contenttext">
            Log out
          </h4>
          <i class="fa fa-sign-out-alt logbtn"></i>
        </div>
      </div>
      
    </div>
    <div class="cartbtn">
      <div class="numbershow">0</div>
      <i class="fa-solid fa-cart-plus cardcolor"></i>
    </div>
    <div class="showImages">
      <div class="imagesection">

<?php
// grab the Imag 
$connectDB = new mysqli("localhost","root", "", "product");
if(mysqli_connect_error()){
die ("the connection is not ready for this problem: ". $connectDB->connect_error || mysqli_connect_error());
}else{
     $sql = 'SELECT * FROM eachproduct where product_id ="'. $_GET["product_id"]. '" ';
     $result = $connectDB->query($sql);
     $mainResult = $result->fetch_all(MYSQLI_ASSOC);
     // print_r($mainResult);
      foreach($mainResult as $key => $value){
           echo '<div class="mainImage">
              <img class="mainImagefull" src="../'. $value["first_image"] .'" alt="'.$value["product_title"]  .'" />
              </div>';
           echo '</div>';


      echo '<div class="contentsection">
        <h1 class="product_name">'.  $value["product_name"]. '</h1>
        <h2 class="product_title">'. $value["product_title"]. ' </h2>
        <h2 class="product_details">'.  $value["product_description"]. '</h2>
        <div class="price">Price: RM'. $value["product_present_price"].  ' </div>
        <div class="productincrease_decrease">
          <div class="plus">+</div>
          <div class="showNumber">0</div>
          <div class="minus">-</div>
        </div>
        <div class="addtocart">add to card</div>
      </div>
    </div>';
  }
}

?>
 
       
    
    <script src="eachproduct.js"></script>
  </body>
</html>
