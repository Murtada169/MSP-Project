let eachproduct = document.querySelectorAll(".eachProduct");
console.log(eachproduct);
let form = document.getElementById("showeachproduct");
let inputa = document.getElementById("productvalue");
eachproduct.forEach((eachproduct) => {
  eachproduct.addEventListener("click", function (e) {
    let productId = eachproduct.getAttribute("data-producutId");
    inputa.value = productId;
    console.log(inputa.value);
    form.submit();
  });
});
