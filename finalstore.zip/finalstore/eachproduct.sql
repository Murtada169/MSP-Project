-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 15, 2022 at 03:11 AM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `product`
--

-- --------------------------------------------------------

--
-- Table structure for table `eachproduct`
--

CREATE TABLE `eachproduct` (
  `id` int(11) NOT NULL,
  `product_id` varchar(50) DEFAULT NULL,
  `product_name` varchar(150) DEFAULT NULL,
  `product_title` varchar(500) DEFAULT NULL,
  `product_description` varchar(1000) DEFAULT NULL,
  `product_present_price` varchar(10) DEFAULT NULL,
  `first_image` varchar(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `eachproduct`
--

INSERT INTO `eachproduct` (`id`, `product_id`, `product_name`, `product_title`, `product_description`, `product_present_price`, `first_image`) VALUES
(1, 'r2', 'Banana', 'Banana is best1', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been', '40', 'image/banana/1.jpg'),
(2, 'r3', 'rose', 'Rose is best3', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been', '50', 'image/rose1/3.jpg'),
(3, 'b1', 'belly', 'belly is best1', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been', '76', 'image/belly1/1.jpg'),
(4, 'b2', 'sunflower', 'sunflower is best2', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been', '88', 'image/sunflower/1.jpg'),
(5, 'b3', 'belly', 'belly is best3', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been', '67', 'image/belly1/3.jpg'),
(6, 'm1', 'apple', 'apple is best1', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been', '99', 'image/apple/1.jpg'),
(7, 'm2', 'mango', 'mango is best2', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been', '35', 'image/mango1/2.jpg'),
(10, 'c1', 'cactus', 'Cactus for man', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been', '53', 'image/cactus/1.jpg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `eachproduct`
--
ALTER TABLE `eachproduct`
  ADD PRIMARY KEY (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
