<?php
if(isset($_GET["searchedValue"]) && $_GET["searchedValue"] != ""){
  $connectDB = new mysqli("localhost","root", "", "product");

  $sql = 'SELECT * FROM eachproduct WHERE product_name LIKE ?;';
  $stmt = $connectDB->prepare($sql);
  $aName = '%' . $_GET['searchedValue'] . '%';
  $stmt->bind_param('s', $aName);
  
  $stmt->execute();
  $getResult = $stmt->get_result();
  $mainResult = $getResult->fetch_all(MYSQLI_ASSOC);
      foreach($mainResult as $key => $value){
           echo "<div class='eachProduct' data-producutId='".$value["product_id"]  ."'>"." <img src='". $value["first_image"] . "' alt='". $value["product_title"] ."'>". 
           "<h1>". $value["product_name"] ."</h1>";
           echo "<p class='price'>Price: RM".$value["product_present_price"] ."</p>";
           echo "</div>";
      }
}
 
if(isset($_GET["sorting"])){
     $connectDB = new mysqli("localhost","root", "", "product");
     if($_GET["sorting"] == "lth"){
       $sql = 'SELECT * FROM eachproduct ORDER BY product_present_price ASC ;';
     }
       if($_GET["sorting"] == "htl"){
       $sql = 'SELECT * FROM eachproduct ORDER BY product_present_price DESC ;';
     }
      if($_GET["sorting"] == "otn"){
       $sql = 'SELECT * FROM eachproduct ORDER BY id ASC ;';
     }
     $result = $connectDB->query($sql);
     $mainResult = $result->fetch_all(MYSQLI_ASSOC);
      echo "<div class='allproduct'>";
      foreach($mainResult as $key => $value){
           echo "<div class='eachProduct' data-producutId='".$value["product_id"]  ."'>";
           echo " <img src='". $value["first_image"] . "' alt='". $value["product_title"] ."'>";
           echo "<h1>". $value["product_name"] ."</h1>";
           echo "<p class='price'>Price: RM ".$value["product_present_price"] ."</p>";
          
           echo "</div>";
      }
     echo "</div>";
}
?>
