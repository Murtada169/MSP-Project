let thesearchbtn = document.getElementById("submiting");
let thesearchvalue = document.getElementById("searchedValue");
thesearchvalue.addEventListener("keyup", (e) => {
  thesearchvalue.value = e.target.value;
});
thesearchbtn.addEventListener("click", () => {
  let searchingValue = thesearchvalue.value;
  var xmlhttp = new XMLHttpRequest();
  xmlhttp.onreadystatechange = function () {
    if (this.readyState == 4 && this.status == 200) {
      document.querySelector(".allproduct").innerHTML = "";
      document.querySelector(".allproduct").innerHTML = this.responseText;

      let eachproduct = document.querySelectorAll(".eachProduct");
      let form = document.getElementById("showeachproduct");
      let inputa = document.getElementById("productvalue");
      eachproduct.forEach((eachproduct) => {
        eachproduct.addEventListener("click", function (e) {
          let productId = eachproduct.getAttribute("data-producutId");
          inputa.value = productId;
          form.submit();
        });
      });
      thesearchvalue.value = "";
    }
  };
  xmlhttp.open(
    "GET",
    "searchingvalue.php?searchedValue=" + searchingValue,
    true
  );
  xmlhttp.send();
});

//the low to high value
// let highttolow = document.getElementById("highttolow");
// highttolow.addEventListener("click", () => {
//   let sortingval = "hightolow";
//   var xmlhttp = new XMLHttpRequest();
//   xmlhttp.onreadystatechange = function () {
//     if (this.readyState == 4 && this.status == 200) {
//       document.querySelector(".allproduct").innerHTML = "";
//       document.querySelector(".allproduct").innerHTML = this.responseText;

//       let eachproduct = document.querySelectorAll(".eachProduct");

//       let form = document.getElementById("showeachproduct");
//       let inputa = document.getElementById("productvalue");
//       eachproduct.forEach((eachproduct) => {
//         eachproduct.addEventListener("click", function (e) {
//           let productId = eachproduct.getAttribute("data-producutId");
//           inputa.value = productId;
//           form.submit();
//         });
//       });
//     }
//   };
//   xmlhttp.open("GET", "searchingvalue.php?sorting=" + sortingval, true);
//   xmlhttp.send();
// });
////the high to low
// let lowtohigh = document.getElementById("lowtohigh");
// lowtohigh.addEventListener("click", () => {
//   let sortingval = "lowtohigh";
//   var xmlhttp = new XMLHttpRequest();
//   xmlhttp.onreadystatechange = function () {
//     if (this.readyState == 4 && this.status == 200) {
//       document.querySelector(".allproduct").innerHTML = "";
//       document.querySelector(".allproduct").innerHTML = this.responseText;

//       let eachproduct = document.querySelectorAll(".eachProduct");
//       let form = document.getElementById("showeachproduct");
//       let inputa = document.getElementById("productvalue");
//       eachproduct.forEach((eachproduct) => {
//         eachproduct.addEventListener("click", function (e) {
//           let productId = eachproduct.getAttribute("data-producutId");
//           inputa.value = productId;
//           form.submit();
//         });
//       });
//     }
//   };
//   xmlhttp.open("GET", "searchingvalue.php?sorting=" + sortingval, true);
//   xmlhttp.send();
// });

let selectbtn = document.getElementById("theselection");
selectbtn.addEventListener("change", (e) => {
  let sortingval = e.target.value;
  var xmlhttp = new XMLHttpRequest();
  xmlhttp.onreadystatechange = function () {
    if (this.readyState == 4 && this.status == 200) {
      document.querySelector(".allproduct").innerHTML = "";
      document.querySelector(".allproduct").innerHTML = this.responseText;

      let eachproduct = document.querySelectorAll(".eachProduct");
      let form = document.getElementById("showeachproduct");
      let inputa = document.getElementById("productvalue");
      eachproduct.forEach((eachproduct) => {
        eachproduct.addEventListener("click", function (e) {
          let productId = eachproduct.getAttribute("data-producutId");
          inputa.value = productId;
          form.submit();
        });
      });
    }
  };
  xmlhttp.open("GET", "searchingvalue.php?sorting=" + sortingval, true);
  xmlhttp.send();
});
// OLD TO NEW
