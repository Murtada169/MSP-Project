<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css"/>
    <link rel="stylesheet" href="style.css">
    <title>Product Page</title>
  </head>
  <body>
    <!-- navigation menu -->
    <div class="navvar forall">
      <div class="logo">
        <img src="image/logo.jpg" alt="">
      </div>
      <div class="allnavsc">
        
        <div class="eachnav notibgc">
          <h4 class="contenttext">
           Notification
          </h4>
        </div>
        <div class="eachnav hmbgc">
          <i class="fa fa-home" aria-hidden="true"></i>
          <h4 class="contenttext">
          <a href="mainpage.php">Admin Home</a> 
          </h4>
        </div>
        <div class="eachnav">
          <i class="fa fa-calendar" aria-hidden="true"></i>
          <h4 class="contenttext">
            Manage Booking
          </h4>
        </div>
        <div class="eachnav bigvlg">
          <span class="big">i</span>
          <h4 class="contenttext">
            Manage Advertisment
          </h4>
        </div>

          <div class="eachnav">
          <h4 class="contenttext">
            Log out
          </h4>
          <i class="fa fa-sign-out-alt logbtn"></i>
        </div>
      </div>
      
    </div>
   <!-- the search bar -->
    <div class="searchInputWrapper">
        <input class="searchInput" id="searchedValue" type="text" placeholder='Search a product'>
        <!-- <i class="fa fa-search searchInputIcon"></i> -->
        <button class="searchbutton" type="submit" id="submiting">
             <i class="fa fa-search searchicon" aria-hidden="true"></i>
        </button>

        </input>
    </div>
    <!-- high to low price and low to high price -->
  
    <!-- <div class=" forall productbyKeysearchsec">
     <button class=" buttonforshow eachkey">T-shirt</button>
     <button class=" buttonforshow eachkey">Slip Shrit</button>
     <button class=" buttonforshow eachkey">Pant</button>
     <button class=" buttonforshow eachkey">Touser</button>
     <button class=" buttonforshow eachkey">T-shirt</button>
     <button class=" buttonforshow eachkey">Slip Shrit</button>
     <button class=" buttonforshow eachkey">Pant</button>
     <button class=" buttonforshow eachkey">Touser</button>
     <button class=" buttonforshow eachkey">T-shirt</button>
     <button class=" buttonforshow eachkey">Slip Shrit</button>
     <button class=" buttonforshow eachkey">Pant</button>
     <button class=" buttonforshow eachkey">Touser</button>
     <button class=" buttonforshow eachkey">Touser</button>
     <button class=" buttonforshow eachkey">Touser</button>
     <button class=" buttonforshow eachkey">Touser</button>
     <button class=" buttonforshow eachkey">Touser</button>
     <button class=" buttonforshow eachkey">Touser</button>
     <button class=" buttonforshow eachkey">Touser</button>
     <button class=" buttonforshow eachkey">Touser</button>
     <button class=" buttonforshow eachkey">Touser</button>
     
    </div> -->
     <div class="filteringPage">
     <h2 class="heading textHighToLow">Sort by: </h2>
     <select id="theselection">
      <option value="htl"><button id="highttolow" class=" buttonforshow highTolow">Highest to Low</button></option>
      <option value="lth"><button id="lowtohigh" class=" buttonforshow lowToHigh">Lowest to High</button></option>
      <option value="otn"><button id="oldtonew" class=" buttonforshow lowToHigh">Old to Newest</button></option>
     </select>
     <!-- <button id="highttolow" class=" buttonforshow highTolow">Highest to Low</button>
     <button id="lowtohigh" class=" buttonforshow lowToHigh">Lowest to High</button>
     <button id="oldtonew" class=" buttonforshow lowToHigh">Old to Newest</button> -->
    </div>
    

<?php
// grab all product from database
$connectDB = new mysqli("localhost","root", "", "product");
if(mysqli_connect_error()){
die ("the connection is not ready for this problem: ". $connectDB->connect_error || mysqli_connect_error());
}else{
     $sql = 'SELECT * FROM eachproduct ORDER BY id DESC';
     $result = $connectDB->query($sql);
     $mainResult = $result->fetch_all(MYSQLI_ASSOC);
     // print_r($mainResult);
      echo "<div class='allproduct'>";
      foreach($mainResult as $key => $value){
           echo "<div class='eachProduct' data-producutId='".$value["product_id"]  ."'>";
           echo " <img src='". $value["first_image"] . "' alt='". $value["product_title"] ."'>";
           echo "<h1>". $value["product_name"] ."</h1>";
           echo "<p class='price'>Price: RM".$value["product_present_price"] ."</p>";
          
           echo "</div>";
      }
     echo "</div>";
    

}

 ?>
    </div>
      <form method="get" id="showeachproduct" action="eachproduct/eachproduct.php">
          <input id="productvalue" name="product_id" value="a" type="hidden">
      </form>
    <script src="search_Rendering.js"></script>
    <script src="product_Rendering.js"></script>
  </body>
</html>
